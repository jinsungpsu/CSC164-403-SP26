module com.example.csc164_firstjavafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.csc164_firstjavafx to javafx.fxml;
    exports com.example.csc164_firstjavafx;
}