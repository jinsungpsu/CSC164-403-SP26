module dtcc.csc164_javafx_blank {
    requires javafx.controls;
    requires javafx.fxml;


    opens dtcc.csc164_javafx_blank to javafx.fxml;
    exports dtcc.csc164_javafx_blank;
}