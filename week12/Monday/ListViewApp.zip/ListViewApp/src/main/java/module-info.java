module dtcc.listviewapp {
    requires javafx.controls;
    requires javafx.fxml;


    opens dtcc.listviewapp to javafx.fxml;
    exports dtcc.listviewapp;
}